def bet_counter_function():
    return "Bet Counter Fonctionnement réussi!"

