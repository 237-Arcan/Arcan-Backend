def init():
    print('Initialisation du module KarmicFlow')
