def init():
    print("app.core.modules prêt.")

def analyse(match_data=None):
    print("Analyse de app.core.modules en cours...")
