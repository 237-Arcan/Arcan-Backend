def init():
    print('Initialisation du module LateSurgeDetector')
