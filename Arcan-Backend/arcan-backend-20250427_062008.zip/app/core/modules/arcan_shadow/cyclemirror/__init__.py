def init():
    print('Initialisation du module CycleMirror')
