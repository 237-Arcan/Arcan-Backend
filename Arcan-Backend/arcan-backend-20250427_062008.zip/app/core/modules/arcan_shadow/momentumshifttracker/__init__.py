def init():
    print('Initialisation du module MomentumShiftTracker')
