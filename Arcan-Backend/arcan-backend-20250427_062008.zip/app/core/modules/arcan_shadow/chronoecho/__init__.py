def init():
    print('Initialisation du module ChronoEcho')
