def shadow_odds_function():
    return "Shadow Odds Fonctionnement réussi!"
