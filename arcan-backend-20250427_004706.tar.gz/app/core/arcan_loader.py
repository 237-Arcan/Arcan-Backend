import importlib
import os

MODULE_PATH = "app/core/modules"

def discover_and_init_modules():
    print("[ARCAN INIT] Démarrage de l'initialisation des modules...\n")

    for dirpath, dirnames, filenames in os.walk(MODULE_PATH):
        if "__init__.py" in filenames:
            relative_path = dirpath.replace("/", ".").replace("\\", ".")
            try:
                module = importlib.import_module(relative_path)
                if hasattr(module, "init"):
                    module.init()
                    print(f"[✓] {relative_path} initialisé.")
                else:
                    print(f"[~] {relative_path} : pas de fonction init() détectée.")
            except Exception as e:
                print(f"[✗] Erreur lors de l'initialisation de {relative_path} : {e}")

    print("\n[ARCAN INIT] Tous les modules scannés.")

if __name__ == "__main__":
    discover_and_init_modules()
