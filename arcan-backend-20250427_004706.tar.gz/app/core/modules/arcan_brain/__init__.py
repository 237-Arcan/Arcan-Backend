def init():
    print('Initialisation de arcan_brain')
