def init():
    print('Initialisation du module YouthImpactAnalyzer')
