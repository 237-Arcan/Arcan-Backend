def init():
    print('Initialisation du module CrowdPressureIndex')
