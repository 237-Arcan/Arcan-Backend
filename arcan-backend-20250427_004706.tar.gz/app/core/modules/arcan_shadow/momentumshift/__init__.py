def init():
    print('Initialisation du module MomentumShift')
