def init():
    print('Initialisation du module ShadowMomentum')
